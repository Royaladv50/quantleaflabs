import React from "react";
import "./index.css";
import { HashRouter as Router, Routes, Route, Link, useLocation } from "react-router-dom";

// Placeholder assets for images and SVG URLs
const USDA = "https://ext.same-assets.com/2078650344/466223838.png";
const GMP = "https://ext.same-assets.com/2078650344/3775056244.png";
const HERO_BG = "https://ext.same-assets.com/2078650344/1783655474.jpeg";
const CARD_IMAGES = [
  "https://ext.same-assets.com/2078650344/2200467708.png",
  "https://ext.same-assets.com/2078650344/2770199533.png",
  "https://ext.same-assets.com/2078650344/1685789394.png",
  "https://ext.same-assets.com/2078650344/1218603237.png",
];
const BADGES = [
  "https://ext.same-assets.com/2078650344/466223838.png",
  GMP,
  "https://ext.same-assets.com/2078650344/3775056244.png",
  "https://ext.same-assets.com/2078650344/1679873325.jpeg",
];

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Products", href: "/products" },
  { label: "Services", href: "/services" },
  { label: "Wholesale", href: "/wholesale" },
  { label: "Contact", href: "/contact" },
];

function Navbar() {
  const location = useLocation();
  const pathname = location.pathname;
  let active = "/";
  if (pathname.startsWith("/products")) active = "/products";
  else if (pathname.startsWith("/services")) active = "/services";
  else if (pathname.startsWith("/wholesale")) active = "/wholesale";
  else if (pathname.startsWith("/contact")) active = "/contact";
  else active = "/";

  return (
    <header className="w-full bg-white border-b border-zinc-200 ">
      <div className="flex flex-col sm:flex-row items-center justify-between px-4 py-3 max-w-7xl mx-auto">
        <div className="flex items-center gap-4"></div>
        <nav className="flex-1 flex items-center justify-center gap-5 mt-2 sm:mt-0">
          {navLinks.map((link) => (
            <Link key={link.label} to={link.href}
              className={
                "text-zinc-900 font-semibold tracking-wide hover:text-[#93aa55] transition-colors text-[1.07rem] uppercase px-3" +
                (active === link.href ? " text-[#93aa55] underline underline-offset-4" : "")
              }
              aria-current={active === link.href ? "page" : undefined}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2 mt-2 sm:mt-0">
          <img src={GMP} alt="GMP Certified" className="h-10 hidden md:block" />
          <img src={USDA} alt="USDA Organic" className="h-12" />
        </div>
      </div>
      <div className="bg-zinc-900 text-zinc-100 text-xs py-1 px-4 text-center font-medium tracking-wider">
        101 Erie Blvd, Canajoharie, NY 13317 | (970) 833-5736
      </div>
    </header>
  );
}

function Hero() {
  const bgHeroImg = "https://ext.same-assets.com/2078650344/1783655474.jpeg";
  return (
    <section
      className="relative w-full overflow-hidden pb-12"
      style={{
        minHeight: 420,
        background: `url(${bgHeroImg}) center/cover no-repeat`,
      }}
    >
      <svg width="420" height="320" viewBox="0 0 210 175" style={{position:'absolute',top:'-60px',left:'-100px',opacity:0.23,zIndex:1}} aria-hidden="true">
        <polygon points="105,7 200,60 200,145 105,168 10,145 10,60" fill="none" stroke="#a6c379" strokeWidth="9" />
      </svg>
      <svg width="490" height="330" viewBox="0 0 210 175" style={{position:'absolute',top:'78px',right:'-140px',opacity:0.13,zIndex:1}} aria-hidden="true">
        <polygon points="105,7 200,60 200,145 105,168 10,145 10,60" fill="none" stroke="#93aa55" strokeWidth="11" />
      </svg>
      <div className="relative z-10 max-w-5xl mx-auto text-center py-14 px-2 flex flex-col items-center" style={{minHeight:330}}>
        <h1
          className="text-white font-extrabold text-3xl sm:text-4xl md:text-5xl tracking-tight mb-3 drop-shadow-[0_5px_14px_rgba(30,44,23,.28)]"
          style={{
            textShadow: "0 3px 12px rgba(22,36,19,0.25),0 2px 8px rgba(0,0,0,0.19)",
          }}
        >
          SUPERIOR PERFORMANCE
        </h1>
        <div className="text-[#a6c379] sm:text-lg font-bold tracking-wide mb-2 uppercase drop-shadow-[0_4px_11px_rgba(0,0,0,0.13)]">
          EXTRACTION • DISTILLATION • ISOLATION • FORMULATION • WHITE LABEL
        </div>
        <Link
          to="/contact"
          className="inline-block mt-3 bg-black/85 text-white px-8 py-3 font-bold rounded-xl shadow-lg transition hover:bg-[#93aa55] hover:text-black text-lg tracking-wide"
        >
          Contact QuantLeaf Labs
        </Link>
      </div>
      <div className="relative z-10 w-full max-w-6xl mx-auto flex flex-wrap justify-center gap-6 -mt-12 pb-2">
        {[
          { title: "Extraction and Finishing Services", img: "https://ext.same-assets.com/2078650344/2200467708.png" },
          { title: "Bulk CBD Extracts, Distillates & Isolates", img: "https://ext.same-assets.com/2078650344/2770199533.png" },
          { title: "Bulk Blends & Formulation", img: "https://ext.same-assets.com/2078650344/1685789394.png" },
          { title: "White/Private Label", img: "https://ext.same-assets.com/2078650344/1218603237.png" },
        ].map((item, i) => (
          <div key={item.title} className="bg-white rounded-xl shadow-lg flex flex-col items-center px-4 py-7 w-56 min-h-[229px] border border-zinc-200">
            <div
              className="w-24 h-24 -mt-9 mb-3 shadow flex items-center justify-center"
              style={{clipPath:"polygon(25% 0%,75% 0%,100% 50%,75% 100%,25% 100%,0% 50%)",background:'#e4efd1'}}>
              <img src={item.img} alt={item.title} className="object-cover w-20 h-20" />
            </div>
            <div className="text-center font-bold text-zinc-700 text-base uppercase mb-1" style={{ letterSpacing: 1 }}>
              {item.title}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function QualitySection() {
  return (
    <section className="bg-[#454545] text-white py-10 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-2xl md:text-3xl font-extrabold mb-2 text-center">
          HEALTH, SAFETY & QUALITY
        </h2>
        <p className="max-w-3xl mx-auto text-center text-zinc-200 mb-8">
          QuantLeaf Labs is focused on the health, safety and well-being of its employees,
          customers and the environment. All products undergo rigorous internal
          testing and are validated by ISO 17025 qualified labs to ensure quality
          and safety. No harmful solvents are used in any QuantLeaf Labs process and all
          processes, process controls, and manufacturing systems are designed to
          meet the requirements of ISO 9001, cGMP, and organic processing. We
          provide complete traceability and transparency throughout the process
          from the biomass to the delivered product. QuantLeaf Labs is committed to
          providing the highest quality products in the industry.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-7 text-center">
          <div>
            <img
              src="https://ext.same-assets.com/2078650344/1783655474.jpeg"
              alt="Bulk Ingredients"
              className="rounded-lg mx-auto w-36 h-28 object-cover mb-2"
            />
            <div className="text-lg font-bold mb-2 text-[#babb3c]">
              Bulk Ingredients
            </div>
            <div className="text-zinc-200 text-sm">
              QuantLeaf Labs provides the finest raw ingredients to make your own
              formulations and products. Our raw ingredients are fully tested &
              documented to the highest standard.
            </div>
          </div>
          <div>
            <img
              src="https://ext.same-assets.com/2078650344/2770199533.png"
              alt="Bulk Blended Products"
              className="rounded-lg mx-auto w-36 h-28 object-cover mb-2"
            />
            <div className="text-lg font-bold mb-2 text-[#babb3c]">
              Bulk Blended Products
            </div>
            <div className="text-zinc-200 text-sm">
              QuantLeaf Labs takes the same raw ingredients and blends the product to your
              specifications. This blend is fully tested and ready for you to
              package, label, and sell to your customers.
            </div>
          </div>
          <div>
            <img
              src="https://ext.same-assets.com/2078650344/1685789394.png"
              alt="Extraction & Finishing"
              className="rounded-lg mx-auto w-36 h-28 object-cover mb-2"
            />
            <div className="text-lg font-bold mb-2 text-[#babb3c]">
              Extraction & Finishing Services
            </div>
            <div className="text-zinc-200 text-sm">
              Extraction services provided with care, attention, traceability,
              and transparency. Resulting extract can be finished to full or
              broad spectrum distillate, organic isolate, or all the way to
              finished product.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function CompanyInfo() {
  const tiles = [
    {
      label: "Quality",
      text: "Rigorous testing and process control standards through every step of the process.",
    },
    {
      label: "Consistency",
      text: "We deliver on-time and on-specification with as little variation as possible.",
    },
    {
      label: "Transparency",
      text: "Complete visibility from the finished product back to the farm.",
    },
    {
      label: "B2B Customer Focus",
      text: "QuantLeaf Labs keeps its focus on business to business customers by providing excellent customer service and meeting unique customer requirements.",
    },
    {
      label: "Integrated Supply Chain",
      text: "QuantLeaf Labs is a one-stop shop providing extraction, ingredients, formulation and packaging.",
    },
    {
      label: "Expertise",
      text: "QuantLeaf Labs is rooted in process control and manufacturing expertise combined with CO2 extraction, CBD, and product development.",
    },
  ];
  return (
    <section className="bg-[#f8f8f6] py-10 px-4">
      <h2 className="text-2xl md:text-3xl font-extrabold mb-4 text-center uppercase text-zinc-800">
        QuantLeaf Labs
      </h2>
      <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5 mb-8">
        {tiles.map((tile) => (
          <div
            className="rounded-lg bg-[#474747] text-white p-6 text-center shadow border-b-4 border-[#babb3c] flex flex-col justify-between"
            key={tile.label}
          >
            <div className="font-bold text-lg mb-1 text-[#babb3c]">{tile.label}</div>
            <div className="text-sm text-zinc-200">{tile.text}</div>
          </div>
        ))}
      </div>
      <div className="flex justify-center gap-6 items-center flex-wrap mb-2">
        {BADGES.map((url, i) => (
          <img
            src={url}
            key={i}
            className="h-16 mx-2 rounded bg-white p-1"
            loading="lazy"
            alt="Certification badge"
          />
        ))}
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-zinc-950 text-zinc-300 py-8 text-sm">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-7 px-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="font-semibold text-[#93aa55] mb-2 border-b border-[#93aa55] inline-block">
            Company Info
          </div>
          <ul className="leading-7">
            <li>
              <Link to="/" className="hover:text-[#93aa55]">
                Home
              </Link>
            </li>
            <li>
              <Link to="/privacy-policy" className="hover:text-[#93aa55]">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms-of-service" className="hover:text-[#93aa55]">
                Terms Of Service
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-[#93aa55]">
                Contact
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <div className="font-semibold text-[#93aa55] mb-2 border-b border-[#93aa55] inline-block">
            Our Products
          </div>
          <ul className="leading-7">
            <li>
              <Link to="/usda-organic" className="hover:text-[#93aa55]">
                USDA Organic
              </Link>
            </li>
            <li>
              <Link to="/products" className="hover:text-[#93aa55]">
                Products
              </Link>
            </li>
            <li>
              <Link to="/farmers" className="hover:text-[#93aa55]">
                Farmers
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <div className="font-semibold text-[#93aa55] mb-2 border-b border-[#93aa55] inline-block">
            Our Services
          </div>
          <ul className="leading-7">
            <li>
              <Link to="/about" className="hover:text-[#93aa55]">
                About
              </Link>
            </li>
            <li>
              <Link to="/products" className="hover:text-[#93aa55]">
                Products
              </Link>
            </li>
            <li>
              <Link to="/services" className="hover:text-[#93aa55]">
                Services
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-[#93aa55]">
                Contact
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <div className="font-semibold text-[#93aa55] mb-2 border-b border-[#93aa55] inline-block">
            Connect With Us
          </div>
          <div className="mb-1">
            101 Erie Blvd
            <br />
            Canajoharie, NY 13317
          </div>
          <div className="mb-1">(970) 833-5736</div>
        </div>
      </div>
      <div className="pt-4 text-center text-xs text-zinc-400">
        © 2025 QuantLeaf Labs. All Rights Reserved.
      </div>
    </footer>
  );
}

function ProductsPage() {
  const categories = [
    {
      title: "Extracts – CBD, CBDA, CBG, CBDV",
      desc: "Derived exclusively from US Grown & Registered Industrial Hemp or USDA Certified Organic Grown & Registered Industrial Hemp that is CO2 extracted using proprietary processes to maximize and optimize the cannabinoid and terpene profile. QuantLeaf Labs CBD Oil is a pure Phytocannabinoid-Rich (PCR) Hemp Oil with a Full Spectrum of cannabinoids and terpenes.",
      items: ["Learn More"],
      learn: "/contact",
      img: "https://ext.same-assets.com/1200634878/1289397902.png",
    },
    {
      title: "Distillates – Full/Broad – CBD/CBG/CBDV",
      desc: "Derived exclusively from QuantLeaf Labs extract and distilled to produce a golden refined product. QuantLeaf Labs CBD Oil Distillate is pure and clean with a broad spectrum of cannabinoids and lighter terpenes, 75%-85% CBD including THC non-detect.",
      items: [
        "Full Spectrum CBD/CBG/CBDv Distillate",
        "THC Non-Detect CBD Distillate",
        "Full Spectrum Compliant Distillate",
      ],
      learn: "/contact",
      img: "https://ext.same-assets.com/1200634878/1807139682.png",
    },
    {
      title: "Certified Organic Isolates – CBD/CBG",
      desc: "QuantLeaf Labs has developed a patented process to produce the purest Certified Organic Isolates. No residual solvents, no hydrocarbons, no contaminants, just pure organic isolate. This is the perfect ingredient for formulation, water soluble, or any product you can imagine.",
      items: ["95-99% pure CBD", "0.0% THC"],
      learn: "/contact",
      img: "https://ext.same-assets.com/1200634878/3428101532.png",
    },
    {
      title: "White/Private Label Products",
      desc: "At QuantLeaf Labs, your success is our success. We go above and beyond to assure that your business thrives. Highest quality certified organic CBD products and services at an exceptional value.",
      items: [
        "Solvent-Free Processing",
        "Process Control and Data-Driven Quality",
        "Quality Verification",
        "Innovation and Product Development",
        "Low MOQs",
      ],
      learn: "/contact",
      img: "https://ext.same-assets.com/2199601977/3025624401.png",
    },
    {
      title: "Bulk Blended Products",
      desc: "QuantLeaf Labs can bulk blend any raw ingredients with any carrier oil to produce a bulk blend to your specification. All blends tested for potency and safety and meet spec.",
      items: ["Solvent-Free Processing", "Certified Organic", "Fast delivery time"],
      learn: "/contact",
      img: "https://ext.same-assets.com/1749177377/2792600393.png",
    },
  ];

  return (
    <div className="pt-0 min-h-screen" style={{ background: "#f9f9f6" }}>
      <section
        className="w-full relative pb-10"
        style={{
          background: `linear-gradient(rgba(32,36,22,0.64),rgba(32,36,22,0.53)),url(${HERO_BG}) center/cover no-repeat`,
        }}
      >
        <div className="max-w-3xl mx-auto text-center py-14 px-2">
          <h1
            className="text-white font-extrabold text-2xl sm:text-4xl md:text-5xl tracking-tight mb-2"
            style={{ textShadow: "0 2px 8px #0004" }}
          >
            YOUR SOURCE OF WHOLESALE CBD OIL & FINISHED PRODUCTS
          </h1>
          <div className="text-[#93aa55] font-semibold text-lg tracking-wide mb-2 uppercase">
            Health, Safety & Quality
          </div>
          <p className="text-zinc-100 max-w-xl mx-auto text-base font-medium">
            QuantLeaf Labs is focused on health, safety, and well-being. Rigorous internal
            testing, ISO-qualified labs, no harmful solvents, maximum traceability,
            organic processing, and industry-best standards.
          </p>
        </div>
      </section>
      <div className="max-w-5xl mx-auto -mt-16 pb-10 px-4 flex flex-wrap gap-y-10 gap-x-8 justify-center">
        {categories.map((cat) => (
          <div
            key={cat.title}
            className="bg-white shadow border rounded-2xl w-full md:w-[370px] min-h-[375px] flex flex-col items-center relative pt-14 pb-7 px-6 text-center"
          >
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-24 h-24 bg-[#e4efd1] rounded-full shadow-lg flex items-center justify-center border-4 border-white">
              <img src={cat.img} className="w-14 h-14 object-contain" alt="" />
            </div>
            <h3 className="text-lg font-bold uppercase mb-2 mt-2 text-[#181817]">
              {cat.title}
            </h3>
            <p className="mb-2 text-[15px] text-zinc-600">{cat.desc}</p>
            <ul className="text-zinc-700 mb-4 text-[15px]">
              {cat.items.map((li) => (
                <li key={li}>{li}</li>
              ))}
            </ul>
            <Link
              to={cat.learn}
              className="inline-block bg-[#93aa55] px-6 py-2 rounded font-semibold text-black shadow hover:bg-black hover:text-white transition"
            >
              Contact Us
            </Link>
          </div>
        ))}
      </div>
      <QualitySection />
      <CompanyInfo />
      <Footer />
    </div>
  );
}

function ServicesPage() {
  const services = [
    {
      title: "Extraction Services",
      image: "https://ext.same-assets.com/2960843342/100088852.png",
      features: ["High Yield", "High CBD", "Low THC", "Terpenes"],
      desc: "QuantLeaf Labs applies full analytical capabilities and provides an extensive report with mass balances and performance analysis to ensure ideal extraction. Plant terpenes maintained, no winterization needed, saving you money and boosting yield.",
      cta: "Contact Us",
    },
    {
      title: "Finishing Services",
      image: "https://ext.same-assets.com/2960843342/1242814905.png",
      features: ["Fast Turnaround", "Full Traceability", "Consistency", "Proven Results"],
      desc: "Post-processing extract/crude into your desired finish. Solutions for Distillates, THC-non-detect, and patent-pending Certified Organic Isolate. Managed with traceability and master records for consistent, high-quality results.",
      cta: "Contact Us",
    },
    {
      title: "Product Development, Formulation & Manufacturing",
      image: "https://ext.same-assets.com/2078650344/2770199533.png",
      features: ["Unique Ingredients", "Rapid Prototyping", "Wealth of Experience", "Organic Development"],
      desc: "Constant research and innovation, working directly with you to create your new formulations and finished products. Rapid prototyping for immediate feedback with an expert science officer.",
      cta: "Contact Us",
    },
  ];
  return (
    <div className="pt-0 min-h-screen" style={{ background: "#f9f9f6" }}>
      <section
        className="w-full relative pb-10"
        style={{ background: `linear-gradient(rgba(32,36,22,0.66),rgba(32,36,22,0.56)),url(${HERO_BG}) center/cover no-repeat` }}
      >
        <div className="max-w-3xl mx-auto text-center py-14 px-2">
          <h1 className="text-white font-extrabold text-2xl sm:text-4xl md:text-5xl tracking-tight mb-1" style={{ textShadow: "0 2px 8px #0004" }}>
            SUPERIOR EXTRACTION PERFORMANCE
          </h1>
          <div className="text-[#93aa55] font-semibold text-lg tracking-wide mb-2 uppercase">And Pure QuantLeaf Labs CBD Oil</div>
          <Link to="/contact" className="inline-block mt-6 bg-[#93aa55] text-black px-7 py-3 font-bold rounded shadow-lg transition hover:bg-black hover:text-white">Contact Us</Link>
        </div>
      </section>
      <div className="max-w-6xl mx-auto flex flex-wrap gap-y-9 gap-x-8 justify-center mt-[-68px] z-10 relative pb-8">
        {services.map((s) => (
          <div key={s.title} className="bg-white rounded-xl shadow-lg flex flex-col items-center px-7 py-9 w-full md:w-[350px] min-h-[369px] border border-zinc-200">
            <div className="w-24 h-24 -mt-12 mb-2 shadow-lg rounded-full bg-[#e7efd9] border-4 border-white flex items-center justify-center"><img src={s.image} alt="" className="w-14 h-14 object-contain"/></div>
            <div className="text-center font-bold text-zinc-800 text-lg uppercase mb-1" style={{ letterSpacing: 1 }}>{s.title}</div>
            <ul className="flex flex-wrap justify-center gap-1 text-[#93aa55] font-semibold text-sm mb-2">
              {s.features.map(f => <li className="px-3 py-0.5 bg-zinc-100 rounded mt-1" key={f}>+ {f.toUpperCase()}</li>)}
            </ul>
            <div className="text-zinc-700 text-[15px] mb-4">{s.desc}</div>
            <Link to="/contact" className="inline-block bg-[#93aa55] px-5 py-2 rounded font-semibold text-black shadow hover:bg-black hover:text-white transition">{s.cta}</Link>
          </div>
        ))}
      </div>
      <QualitySection />
      <CompanyInfo />
      <Footer />
    </div>
  );
}

function WholesalePage() {
  return (
    <div className="pt-0 min-h-screen" style={{ background: "#f9f9f6" }}>
      <section
        className="w-full relative pb-6"
        style={{ background: `linear-gradient(rgba(32,36,22,0.64),rgba(32,36,22,0.55)),url(${HERO_BG}) center/cover no-repeat` }}
      >
        <div className="max-w-3xl mx-auto text-center py-14 px-2">
          <h1 className="text-white font-extrabold text-2xl sm:text-4xl md:text-5xl tracking-tight mb-2" style={{textShadow:'0 2px 8px #0004'}}>
            YOUR SOURCE OF WHOLESALE CBD OIL & WHITE LABEL
          </h1>
          <div className="text-zinc-200 text-lg tracking-wide mt-2 mb-1">Colorado-Made CBD Extracts</div>
          <Link to="/contact" className="inline-block mt-5 bg-[#93aa55] text-black px-7 py-3 font-bold rounded shadow-lg transition hover:bg-black hover:text-white">Contact Us Today!</Link>
        </div>
      </section>
      <section className="py-8" style={{ background: "#fff" }}>
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-2xl font-bold mb-2">Build Your Brand With Certified Organic, Wholesale CBD Oil & White Label</h2>
          <p className="text-zinc-700 mb-6">Are you thinking about starting a CBD brand or improving one you currently own? Our flagship Certified Organic Isolate and innovative CBD distillates can only be produced and sold from our lab. Take your CBD brand's success to new heights—contact our team to discuss how our high-quality wholesale/white label CBD oil and distillates can improve your brand.</p>
          <Link to="/contact" className="bg-[#93aa55] px-7 py-2 font-semibold rounded shadow text-black hover:bg-black hover:text-white transition">Contact Us Today!</Link>
        </div>
      </section>
      <section className="py-10" style={{ background: "#f4f4f2" }}>
        <div className="max-w-4xl mx-auto px-6">
          <h3 className="text-2xl font-bold mb-4">Why Choose QuantLeaf Labs?</h3>
          <p className="text-zinc-700 mb-4">Partner with our experienced team in Colorado to produce the highest-quality wholesale and white-label CBD oil for your business. Take advantage of our certifications, advanced manufacturing execution system, and innovative product development services for the competitive edge you need.</p>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 mb-2">
            <li className="text-[#93aa55] font-medium">• USDA Organic Certified</li>
            <li className="text-[#93aa55] font-medium">• Full traceability for all products</li>
            <li className="text-[#93aa55] font-medium">• One-stop shop for extraction, distillates, and finished products</li>
            <li className="text-[#93aa55] font-medium">• Product development & rapid prototyping services</li>
          </ul>
          <p className="text-zinc-700 mt-6">Whether you're launching a new business or scaling up, QuantLeaf Labs can deliver the innovation and quality you need. Get in touch with us to learn more.</p>
          <Link to="/contact" className="block w-max mt-5 bg-[#93aa55] px-6 py-2 font-semibold rounded shadow text-black hover:bg-black hover:text-white transition">Contact a member of our team now.</Link>
        </div>
      </section>
      <QualitySection />
      <CompanyInfo />
      <Footer />
    </div>
  );
}

function ContactPage() {
  return (
    <div className="min-h-screen" style={{ background: "#f8f8f6" }}>
      <section className="max-w-5xl mx-auto px-3 sm:flex gap-12 pt-10 pb-12">
        <form className="bg-[#737373] rounded-xl flex-1 px-6 py-8 mb-10 sm:mb-0">
          <h2 className="text-xl font-bold text-white text-center mb-5">Contact Us</h2>
          <div className="flex gap-3 mb-3">
            <input type="text" placeholder="First Name" required className="w-1/2 rounded p-2 mb-2" />
            <input type="text" placeholder="Last Name" required className="w-1/2 rounded p-2 mb-2" />
          </div>
          <div className="flex gap-3 mb-3">
            <input type="email" placeholder="Email" required className="w-1/2 rounded p-2 mb-2" />
            <input type="text" placeholder="Phone (optional)" className="w-1/2 rounded p-2 mb-2" />
          </div>
          <textarea placeholder="Questions or Comments" required className="w-full h-28 rounded p-2 mb-3" />
          <div className="flex items-center gap-2 mb-3">
            <input type="checkbox" required id="captcha" className="accent-[#93aa55]" />
            <label htmlFor="captcha" className="text-white text-xs">I'm not a robot</label>
          </div>
          <button type="submit" className="w-full bg-[#93aa55] text-black text-lg font-bold py-2 rounded hover:bg-black hover:text-white transition">Submit</button>
        </form>
        <div className="flex-1 bg-white rounded-xl px-6 py-8 border border-zinc-200 h-fit">
          <h3 className="text-xl font-bold mb-3 text-[#1a3418]">We'd Love To Hear From You.</h3>
          <p className="text-zinc-700 mb-5">We partner with businesses large and small to deliver superior products and services. Please reach out to discuss the specifics of your ongoing needs or project.</p>
          <div className="mb-2 text-zinc-900 font-semibold">QuantLeaf Labs, LLC</div>
          <div className="mb-1">101 Erie Blvd, Canajoharie, NY 13317</div>
          <div className="mb-1">(970) 833-5736</div>
          <div className="mb-4"><a href="mailto:scott@rmextract.com" className="text-sky-700 underline">scott@rmextract.com</a></div>
          <iframe title="map" src="https://www.google.com/maps?q=101%20Erie%20Blvd%2C%20Canajoharie%2C%20NY%2013317&output=embed" className="border w-full rounded h-40" loading="lazy"></iframe>
        </div>
      </section>
      <Footer />
    </div>
  );
}

function PrivacyPolicyPage() {
  return (
    <div className="max-w-3xl mx-auto py-10 px-6" style={{ background: '#fafafa' }}>
      <h1 className="text-3xl font-bold mb-2 text-zinc-800">Privacy Policy</h1>
      <p className="text-zinc-500 mb-6 text-sm">Last Updated on 12-29-2020. This policy is effective immediately.</p>
      <h2 className="text-xl font-bold mt-7">Introduction</h2>
      <p className="mb-4">At QuantLeaf Labs (the “Company” or “We”), we respect your privacy and are committed to protecting it through our compliance with this policy. This policy describes the types of information we may collect from you or that you may provide when you visit this website (our Website) and our practices for collecting, using, maintaining, protecting and disclosing that information.</p>
      <p className="mb-4">This policy applies to information we collect:
        <ul className="list-disc list-inside ml-4">
          <li>On this Website.</li>
          <li>In email, text and other electronic messages between you and this Website.</li>
          <li>Through mobile and desktop applications you download from this Website, which provide dedicated non-browser-based interaction between you and this Website.</li>
          <li>When you interact with our advertising and applications on third-party websites and services, if those applications or advertising include links to this policy.</li>
        </ul>
      </p>
      <p className="mb-4">It does not apply to information collected by:
        <ul className="list-disc list-inside ml-4">
          <li>us offline or through any other means, including on any other website operated by Company or any third party (including our affiliates and subsidiaries); or</li>
          <li>any third party (including our affiliates and subsidiaries), including through any application or content (including advertising) that may link to or be accessible from or on the Website.</li>
        </ul>
      </p>
      <p className="mb-4">Please read this policy carefully to understand our policies and practices regarding your information and how we will treat it. If you do not agree with our policies and practices, your choice is not to use our Website. By accessing or using this Website, you agree to this privacy policy. This policy may change from time to time. Your continued use of this Website after we make changes is deemed to be acceptance of those changes, so please check the policy periodically for updates.</p>

      <h2 className="text-lg font-bold mt-7">Children Under the Age of 13</h2>
      <p className="mb-4">Our Website is not intended for children under 13 years of age. No one under age 13 may provide any personal information to or on the Website. We do not knowingly collect personal information from children under 13. If you are under 13, do not use or provide any information on this Website or on or through any of its features/register on the Website, make any purchases through the Website, use any of the interactive or public comment features of this Website or provide any information about yourself to us, including your name, address, telephone number, e-mail address or any screen name or user name you may use. If we learn we have collected or received personal information from a child under 13 without verification of parental consent, we will delete that information. If you believe we might have any information from or about a child under 13, please contact us via our contact us link.</p>

      <h2 className="text-lg font-bold mt-7">Information We Collect About You and How We Collect It</h2>
      <p className="mb-2">We collect several types of information from and about users of our Website, including information:</p>
      <ul className="list-disc list-inside mb-4 ml-4">
        <li>by which you may be personally identified, such as name, postal address, e-mail address, telephone number or any other information defined as personal or personally identifiable under an applicable law (personal information);</li>
        <li>that is about you but individually does not identify you, and/or</li>
        <li>about your internet connection, the equipment you use to access our Website and usage details.</li>
      </ul>
      <p className="mb-4">We collect this information:
        <ul className="list-disc list-inside ml-4">
          <li>Directly from you when you provide it to us.</li>
          <li>Automatically as you navigate through the site. Information collected automatically may include usage details, IP addresses and information collected through cookies, web beacons and other tracking technologies.</li>
          <li>From third parties, for example, our business partners.</li>
        </ul>
      </p>

      <h2 className="text-lg font-bold mt-7">Information You Provide to Us</h2>
      <ul className="list-disc list-inside mb-4 ml-4">
        <li>Information that you provide by filling in forms on our Website. This includes information provided at the time of registering to use our Website, subscribing to our service, posting material or requesting further services. We may also ask you for information when you report a problem with our Website.</li>
        <li>Records and copies of your correspondence (including e-mail addresses), if you contact us.</li>
        <li>Your responses to surveys that we might ask you to complete for research purposes.</li>
        <li>Details of transactions you carry out through our Website and of the fulfillment of your orders. You may be required to provide financial information before placing an order through our Website.</li>
        <li>Your search queries on the Website.</li>
      </ul>
      <p className="mb-4">You also may provide information to be published or displayed (hereinafter, posted) on public areas of the Website, or transmitted to other users of the Website or third parties (collectively, "User Contributions"). Your User Contributions are posted on and transmitted to others at your own risk. Although we limit access to certain pages/you may set certain privacy settings for such information by logging into your account profile, please be aware that no security measures are perfect or impenetrable. Additionally, we cannot control the actions of other users of the Website with whom you may choose to share your User Contributions. Therefore, we cannot and do not guarantee that your User Contributions will not be viewed by unauthorized persons.</p>

      <h2 className="text-lg font-bold mt-7">Information We Collect Through Automatic Data Collection Technologies</h2>
      <p className="mb-4">As you navigate through and interact with our Website, we may use automatic data collection technologies to collect certain information about your equipment, browsing actions and patterns, including:
        <ul className="list-disc list-inside ml-4">
          <li>Details of your visits to our Website, including traffic data, location data, and other communication data and the resources that you access and use on the Website.</li>
          <li>Information about your computer and internet connection, including your IP address, operating system and browser type.</li>
        </ul>
      </p>
      <p className="mb-4">We also may use these technologies to collect information about your online activities over time and across third-party websites or other online services (behavioral tracking). The information we collect automatically is statistical data and does not include personal information, but we may maintain it or associate it with personal information we collect in other ways or receive from third parties...</p>
      {/* For space, shortened—full text would be inserted in production. */}
    </div>
  );
}

function TermsOfServicePage() {
  return (
    <div className="max-w-3xl mx-auto py-10 px-6" style={{ background: '#fafafa' }}>
      <h1 className="text-3xl font-bold mb-2 text-zinc-800">Terms Of Service</h1>
      <p className="text-zinc-500 mb-5 text-sm">Most recent update: see official policy site for the most current version.</p>
      <h2 className="text-xl font-bold mt-7">Overview</h2>
      <p className="mb-4">This website is operated by QuantLeaf Labs. Throughout the site, the terms we, us, and our refer to QuantLeaf Labs. Accessing or using this site means you accept all the terms, policies, and notices stated here. If you do not agree, discontinue use of the site immediately.</p>
      <h2 className="text-lg font-bold mt-6">Section 1 – Online Store Terms</h2>
      <p className="mb-4">By using the site, you represent you are at least the age of majority in your state/province. You may not use our products or site for any illegal or unauthorized purpose nor violate any laws in your jurisdiction.</p>
      <h2 className="text-lg font-bold mt-6">Section 2 – General Conditions</h2>
      <p className="mb-4">We reserve the right to refuse service to anyone, for any reason, at any time. Your content (excluding credit card info) may be transferred unencrypted and involve transmissions over various networks. Credit card information is always encrypted during transfer. You agree not to duplicate, copy, sell or exploit any portion of the Service without express written permission from us.</p>
      <h2 className="text-lg font-bold mt-6">Section 3 – Accuracy, Completeness, and Timeliness of Information</h2>
      <p className="mb-4">The material on this site is provided for general information only. We reserve the right to modify contents at any time, but do not promise to update information.</p>
      <h2 className="text-lg font-bold mt-6">Section 4 – Modifications to the Service and Prices</h2>
      <p className="mb-4">Prices for our products may change without notice. We reserve the right to modify or discontinue the Service at any time.</p>
      <h2 className="text-lg font-bold mt-6">Section 5 – Products or Services</h2>
      <p className="mb-4">Certain products or services may only be available online and may have limited quantities. Colors and images of products are intended to be as accurate as possible.</p>
      <h2 className="text-lg font-bold mt-6">Section 6 – Accuracy of Billing and Account Info</h2>
      <p className="mb-4">We reserve the right to refuse any order. It is your responsibility to provide current, complete, and accurate information for all purchases at our store.</p>
      <h2 className="text-lg font-bold mt-6">Section 7 – Optional Tools</h2>
      <p className="mb-4">We may provide access to third-party tools over which we neither monitor nor have any control.</p>
      <h2 className="text-lg font-bold mt-6">Section 8 – Third-Party Links</h2>
      <p className="mb-4">Third-party links on this site may direct you to websites not affiliated with us. Complaints or questions regarding third-party products should be directed to the third-party.</p>
      <h2 className="text-lg font-bold mt-6">Section 9 – User Comments, Feedback, and Submissions</h2>
      <p className="mb-4">Your submissions to us may be used without restriction. You are solely responsible for any comments you make and their accuracy.</p>
      <h2 className="text-lg font-bold mt-6">Section 10 – Personal Information</h2>
      <p className="mb-4">Submission of personal information through the store is governed by our Privacy Policy.</p>
      <h2 className="text-lg font-bold mt-6">Section 12 – Prohibited Uses</h2>
      <p className="mb-4">You are prohibited from using the site or its content for: unlawful purposes, violating intellectual property rights, discriminating or harassing, submitting false or misleading information, spamming, uploading viruses, or interfering with security features.</p>
      <h2 className="text-lg font-bold mt-6">Section 13 – Disclaimer of Warranties; Limitation of Liability</h2>
      <p className="mb-4">Your use of the service is at your sole risk. The service and all products delivered to you are provided 'as is' and 'as available' unless otherwise stated. We make no warranty as to service continuity, accuracy, or reliability, and are not liable for any damages arising from use of the service.</p>
    </div>
  );
}

function USDAOrganicPage() {
  return (
    <div className="max-w-3xl mx-auto py-10 px-6" style={{ background: '#fafafa' }}>
      <h1 className="text-3xl font-bold mb-4 text-zinc-800">USDA Organic Certified CBD Oil & Extracts</h1>
      <h2 className="text-xl font-bold mt-8 mb-2">Your Source for USDA Organic Certified CBD</h2>
      <p className="mb-4">QuantLeaf Labs is fully committed to USDA Organic methods and offers rigorously-tested, certified organic CBD extracts for both businesses and consumers. Our processes, documentation, and facility are all audited annually to guarantee compliance with the strictest organic standards.</p>
      <h3 className="font-semibold text-lg mt-6 mb-2">What Is USDA Certified Organic CBD?</h3>
      <p className="mb-3">Certified organic hemp is rare. We start with certified organic hemp and maintain records, food-grade stainless equipment, and approved processes throughout extraction, distillation, and finishing—meeting USDA requirements from start to finish.</p>
      <h3 className="font-semibold mt-10">Why Choose Organic?</h3>
      <ul className="list-disc list-inside mb-3 ml-4">
        <li><b>Customer trust:</b> Organic certification builds real confidence, separating you from the typical CBD crowd.</li>
        <li><b>Marketability:</b> Gain a clear marketing edge—labeled organic CBD is highly desirable and rare in the industry.</li>
        <li><b>Environmental responsibility:</b> We use only safe, sustainable farming and natural processing methods.</li>
      </ul>
      <h3 className="font-semibold mt-10">Our USDA Organic Certified Services</h3>
      <ul className="list-disc list-inside mb-3 ml-4">
        <li><b>Organic CBD Extraction</b></li>
        <li><b>Custom finishing</b> (isolation, remediation, distillation, etc.)</li>
        <li><b>White Label & Private Label development</b></li>
        <li><b>Product formulation & manufacturing</b></li>
      </ul>
      <p className="mb-4">Want to bring organic credibility to your CBD products and brand? <Link to="/contact" className="text-[#93aa55] underline">Contact us today</Link> to discuss our USDA certified extraction and formulation contracts.</p>
      <img className="my-8 mx-auto block rounded shadow" src="https://ext.same-assets.com/2161413293/4068585004.png" alt="USDA Organic Seal" width={124} />
    </div>
  );
}

function FarmersPage() {
  return (
    <div className="max-w-3xl mx-auto py-10 px-6" style={{ background: '#fafafa' }}>
      <h1 className="text-3xl font-bold mb-4 text-zinc-800">QuantLeaf Labs Farmers</h1>
      <h2 className="text-xl font-bold mt-8 mb-2">Partnering with Farmers to Produce the Best CBD Oil</h2>
      <p className="mb-4">At QuantLeaf Labs, we believe the best oil starts with the best hemp. We work with dedicated farmers across the USA who use true organic farming strategies—no pesticides, no herbicides, and a commitment to soil and water management for the purest, safest crop possible. Our promise: every batch is the result of care for the environment and the customer.</p>
      <h3 className="font-semibold text-lg mt-7 mb-2">Why Does Extraction Method Matter?</h3>
      <p className="mb-4">We use only CO2 extraction for our hemp—never butane, propane, or ethanol. This means:</p>
      <ul className="list-disc list-inside mb-4 ml-4">
        <li>100% pure plant extract, no residual solvents</li>
        <li>Environmentally responsible, non-toxic, and renewable</li>
        <li>High yield and efficiency—more cannabinoids, rich in terpenes</li>
      </ul>
      <h3 className="font-semibold mt-8">Are You a Hemp Farmer?</h3>
      <p className="mb-4">QuantLeaf Labs is open to working with farmers nationwide who value quality extraction as much as they do quality cultivation. If you’re interested in working with us for extraction services, capacity reservations, or product development partnerships, <Link to="/contact" className="text-[#93aa55] underline">reach out to us today</Link>.</p>
    </div>
  );
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={
        <>
          <Hero />
          <QualitySection />
          <CompanyInfo />
          <Footer />
        </>
      } />
      <Route path="/products" element={<ProductsPage />} />
      <Route path="/services" element={<ServicesPage />} />
      <Route path="/wholesale" element={<WholesalePage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
      <Route path="/terms-of-service" element={<TermsOfServicePage />} />
      <Route path="/usda-organic" element={<USDAOrganicPage />} />
      <Route path="/farmers" element={<FarmersPage />} />
    </Routes>
  );
}

function App() {
  const mainBg = "#f8f8f6";
  return (
    <Router>
      <div className="font-sans min-h-screen flex flex-col" style={{ background: mainBg }}>
        <Navbar />
        <main className="flex-1">
          <AppRoutes />
        </main>
      </div>
    </Router>
  );
}

export default App;
